export 'package:package_resolver/package_resolver.dart'
    if (dart.library.js) 'sync_package_resolver/node.dart';
